#!/bin/sh

MODE=$1
NUM=$2
THREADS=$3

if [ -z $MODE ] || [ -z $NUM ] || [ -z $THREADS ]; then
	echo "oops"
	exit 1
fi

for test in ro rw wo; do
	(mkdir -p $test/$MODE/$NUM && cd $test/$MODE/$NUM && \
		../../../../custom-$test.sh $THREADS)
done
